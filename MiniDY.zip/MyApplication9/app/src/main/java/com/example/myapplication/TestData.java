package com.example.myapplication;


import android.widget.ImageView;

public class TestData {

    String title;
    String date;
    String info;

    public TestData(String title, String date, String info) {
        this.title = title;
        this.date = date;
        this.info = info;
    }
}